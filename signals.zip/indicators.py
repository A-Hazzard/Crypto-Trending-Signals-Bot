import pandas as pd
import numpy as np

def calculate_ema(prices, period=200):
    return prices.ewm(span=period, adjust=False).mean()

def calculate_ema_short(prices, period=50):  # New shorter-term EMA
    return prices.ewm(span=period, adjust=False).mean()

def calculate_macd(prices, slow=26, fast=12, signal=9):
    exp1 = prices.ewm(span=fast, adjust=False).mean()
    exp2 = prices.ewm(span=slow, adjust=False).mean()
    macd = exp1 - exp2
    signal_line = macd.ewm(span=signal, adjust=False).mean()
    histogram = macd - signal_line  # New: Calculate the MACD histogram
    return macd, signal_line, histogram

def calculate_rsi(prices, period=14):
    delta = prices.diff(1)
    gain = (delta.where(delta > 0, 0)).rolling(window=period).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
    rs = gain / loss
    rsi = 100 - (100 / (1 + rs))
    return rsi
